import React from "react";
import Result from "./_components/Result";

const ViewResult = () => {
  return (
    <div>
      <Result />
    </div>
  );
};

export default ViewResult;
