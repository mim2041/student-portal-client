import React from "react";
import DashboardHome from "./dashboard-home/DashboardHome";

const Dashboard = () => {
  return (
    <div>
      <DashboardHome />
    </div>
  );
};

export default Dashboard;
