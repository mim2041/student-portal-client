import React from "react";
import ApplicationForm from "./_components/ApplicationForm";

const ExamApplication = () => {
  return (
    <div>
      <ApplicationForm></ApplicationForm>
    </div>
  );
};

export default ExamApplication;
