import React from "react";
import Testimony from "./_components/Testimony";

const Testimonial = () => {
  return (
    <div>
      <Testimony></Testimony>
    </div>
  );
};

export default Testimonial;
