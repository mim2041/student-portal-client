export const base_url = import.meta.env.VITE_base_url;
// export const base_url = import.meta.env.VITE_base_url_local;
export const base_url_local = import.meta.env.VITE_base_url_local;
export const imgbb_url = import.meta.env.VITE_imgbb_url;
