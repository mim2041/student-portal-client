

const classNames = (...args) => args.filter(Boolean).join(" ");

export default classNames;